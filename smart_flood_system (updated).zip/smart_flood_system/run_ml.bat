@echo off
setlocal
cd /d "%~dp0"
title Bangladesh Flood Risk - NASA POWER model

where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found. Install Python from python.org and tick "Add Python to PATH".
  pause
  exit /b 1
)

if not exist .venv\Scripts\activate.bat (
  echo First-time setup: creating the Python environment ^(2-3 minutes^)...
  python -m venv .venv
  call .venv\Scripts\activate.bat
  python -m pip install --upgrade pip
  pip install -r requirements.txt
  if errorlevel 1 (
    echo Package install failed. Check your internet connection and run this file again.
    pause
    exit /b 1
  )
) else (
  call .venv\Scripts\activate.bat
)

:menu
echo.
echo ==============================================================
echo   Bangladesh 64-district flood risk  ^(NASA POWER daily data^)
echo ==============================================================
echo   [1] FIRST TIME: download data, train the model, predict  ^(20-40 min^)
echo   [2] Update today's predictions only                       ^(about 1 min^)
echo   [3] Open the district risk map in the browser
echo   [4] Re-train after editing data\flood_labels\bd_flood_events.csv
echo   [5] Check my setup ^(internet, NASA, data^)
echo   [Q] Quit
echo.
choice /c 12345Q /n /m "Choose: "
if errorlevel 6 goto :eof
if errorlevel 5 goto doctor
if errorlevel 4 goto retrain
if errorlevel 3 goto web
if errorlevel 2 goto predict
if errorlevel 1 goto all

:all
python -m floodml all
pause
goto menu

:predict
python -m floodml predict
pause
goto menu

:retrain
python -m floodml labels
python -m floodml dataset
python -m floodml train
pause
goto menu

:doctor
python -m floodml doctor
pause
goto menu

:web
echo Starting the web app. Keep this window open; press Ctrl+C to stop.
start "" cmd /c "timeout /t 6 /nobreak >nul & start http://127.0.0.1:8000/bangladesh"
python -m uvicorn backend.main:app
goto menu
