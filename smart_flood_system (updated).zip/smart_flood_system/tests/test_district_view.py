"""Tests for the per-district data used by the dashboard. Run:  python -m unittest -v tests.test_district_view"""
import json
import tempfile
import unittest
from pathlib import Path

import pandas as pd

from floodml import config
from floodml.district_view import district_payload, list_districts


class DistrictViewTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.saved = (config.POWER_DIR, config.PRED_JSON)
        config.POWER_DIR = self.tmp / "power"
        config.POWER_DIR.mkdir()
        config.PRED_JSON = self.tmp / "pred.json"

    def tearDown(self):
        config.POWER_DIR, config.PRED_JSON = self.saved

    def test_64_districts_listed(self):
        d = list_districts()
        self.assertEqual(len(d), 64)
        self.assertEqual(len({x["location_id"] for x in d}), 64)

    def test_payload_without_data_gives_clear_notes(self):
        p = district_payload(101)
        self.assertEqual(p["weather"], [])
        self.assertIsNone(p["prediction"])
        self.assertEqual(len(p["notes"]), 2)

    def test_payload_with_data(self):
        idx = pd.date_range("2026-10-01", periods=100, name="date")
        df = pd.DataFrame({"IMERG_PRECTOT": [None] * 5 + [2.0] * 95, "PRECTOTCORR": 1.0, "T2M": 27.0, "RH2M": 80.0}, index=idx)
        df.iloc[-2:, :] = float("nan")                      # NASA data lag at the end
        df.to_csv(config.POWER_DIR / "101.csv")
        config.PRED_JSON.write_text(json.dumps({"meta": {"as_of": "2026-12-01"}, "districts": [
            {"location_id": 101, "district": "Gazipur", "risk_level": "LOW", "probability": 0.01}]}))
        p = district_payload(101)
        self.assertEqual(len(p["weather"]), 90)
        self.assertEqual(p["weather"][-1]["date"], "2027-01-06")   # last 2 empty (NASA-lag) days dropped
        self.assertEqual(p["prediction"]["risk_level"], "LOW")
        self.assertEqual(p["notes"], [])
        self.assertTrue(any("2024" in h["event_date"] for h in district_payload(149)["history"]))  # Habiganj events

    def test_unknown_district(self):
        with self.assertRaises(KeyError):
            district_payload(99999)


if __name__ == "__main__":
    unittest.main()
