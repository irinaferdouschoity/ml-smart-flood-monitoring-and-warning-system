// Smoke test of frontend/app.js with a fake browser. Run:  node tests/ui_smoke.js
const fs = require("fs");
const vm = require("vm");
const assert = require("assert");

function fakeEl() {
  const el = {
    value: "", textContent: "", style: {}, children: [], handlers: {}, disabled: false, label: "",
    appendChild(c) { this.children.push(c); return c; },
    replaceChildren(...c) { this.children = c; this.textContent = ""; },
    addEventListener(ev, fn) { this.handlers[ev] = fn; },
    classList: { add() {}, remove() {} },
  };
  return el;
}
const els = {};
const docHandlers = {};
const document = {
  getElementById: id => (els[id] ||= fakeEl()),
  createElement: () => fakeEl(),
  addEventListener: (ev, fn) => { docHandlers[ev] = fn; },
};
const markers = [];
const L = {
  map: () => ({ setView() { return this; }, eachLayer() {}, removeLayer() {} }),
  tileLayer: () => ({ addTo() {} }),
  circleMarker: () => { const m = { styled: null, addTo() { return this; }, bindPopup() { return this; },
    setStyle(s) { this.styled = s; }, setRadius() {} }; markers.push(m); return m; },
  CircleMarker: class {},
};
const charts = [];
class Chart { constructor(c, cfg) { this.cfg = cfg; charts.push(this); } destroy() {} }

const pred = { rank: 3, location_id: 101, district: "Gazipur", division: "Dhaka", as_of: "2026-11-10", horizon_days: 3,
  probability: 0.1234, risk_level: "HIGH", rain_1d_mm: 5.1, rain_3d_mm: 40.2, rain_7d_mm: 80.5, soil_wetness_root: 0.71 };
const meta = { as_of: "2026-11-10", horizon_days: 3, caveat: "Research model." };
const weather = Array.from({ length: 10 }, (_, i) => ({ date: `2026-11-0${i % 9 + 1}`, precipitation: i, temperature_avg: 25, humidity: 80 }));
let withPred = true;

async function fetch(url, opts = {}) {
  const ok = (data, status = 200) => ({ ok: status < 400, status, text: async () => JSON.stringify(data) });
  if (url === "/locations") return ok([{ location_id: 1, location_name: "Dhaka", country: "Bangladesh", latitude: 23.8, longitude: 90.4 }]);
  if (url.startsWith("/weather/")) return ok([]);
  if (url.startsWith("/flood-history/")) return ok([]);
  if (url.startsWith("/rainfall-indicator/")) return ok({});
  if (url === "/bd/districts") return ok([
    { location_id: 1, district: "Dhaka", division: "Dhaka", latitude: 23.8, longitude: 90.4 },
    { location_id: 101, district: "Gazipur", division: "Dhaka", latitude: 24, longitude: 90.4 }]);
  if (url === "/bd/predictions") return withPred ? ok({ meta, districts: [pred] }) : ok({ detail: "No predictions yet." }, 404);
  if (url === "/bd/district/101") return ok({ location_id: 101, district: "Gazipur", division: "Dhaka", latitude: 24, longitude: 90.4,
    prediction: withPred ? pred : null, prediction_meta: meta, weather,
    history: [{ event_date: "2024-06-15 to 2024-06-30", severity: "medium confidence", description: "x" }],
    notes: withPred ? [] : ["No prediction yet."] });
  if (url === "/bd/refresh") return ok({});
  throw new Error("unexpected url " + url);
}

const ctx = { document, L, Chart, fetch, console, Promise, Number, String, Array, JSON, Object, Math, Error };
ctx.window = ctx;
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(__dirname + "/../frontend/app.js", "utf8"), ctx);

(async () => {
  await docHandlers.DOMContentLoaded();
  await new Promise(r => setTimeout(r, 20));

  const select = els.locations;
  const group = select.children.find(c => c.label && c.label.includes("Bangladesh districts"));
  assert(group, "district option group missing");
  assert.strictEqual(group.children.length, 2);
  assert(els["bd-all"].children.length >= 2, "all-districts table missing");
  assert.strictEqual(markers[markers.length - 1].styled.fillColor, "#ef6c00", "marker not coloured by risk");

  // choose a district -> data loads
  select.value = "bd:101";
  await select.handlers.change();
  assert.strictEqual(els.risk.textContent, "HIGH");
  assert.strictEqual(els.prob.textContent, "12.3%");
  assert(charts.length >= 3, "charts not drawn");

  // run prediction -> detail box filled
  els.risk.textContent = "--";
  await els.predict.handlers.click();
  assert.strictEqual(els.risk.textContent, "HIGH");
  assert(els["haor-result"].children.length >= 6, "detail panel not filled");
  assert(els.status.textContent.includes("Gazipur"));

  // refresh button with a district selected uses /bd/refresh
  await els.refresh.handlers.click();
  assert(els.status.textContent.includes("updated"), els.status.textContent);

  // no model yet -> clear message, no crash
  withPred = false;
  await els.predict.handlers.click();
  assert(els.status.textContent.startsWith("Error:") && els.status.textContent.includes("No prediction"), els.status.textContent);
  console.log("UI smoke test OK");
})().catch(e => { console.error("FAILED:", e.message); process.exit(1); });
