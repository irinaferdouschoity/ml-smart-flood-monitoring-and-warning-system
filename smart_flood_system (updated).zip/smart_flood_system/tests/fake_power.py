"""A fake NASA POWER server for offline tests (synthetic numbers - never use for real results)."""
from datetime import date, timedelta

import numpy as np
import pandas as pd

from floodml import config
from floodml.names import norm

FIRST, LAST = date(2021, 1, 1), date(2026, 12, 31)
ALL_DAYS = pd.date_range(FIRST, LAST)


class FakeResponse:
    def __init__(self, status=200, payload=None, text=""):
        self.status_code, self._payload, self.text = status, payload, text

    def json(self):
        return self._payload


class FakePower:
    """Mimics the API: IMERG not in community AG, GWETPROF nowhere, data lags a few days."""

    def __init__(self):
        self.calls = 0
        d = pd.read_csv(config.DISTRICTS_CSV)
        self.pts = {(round(r.latitude, 4), round(r.longitude, 4)): int(r.location_id) for r in d.itertuples()}
        ev = pd.read_csv(config.EVENTS_CSV)
        self.windows = {}
        key = {norm(n): int(i) for n, i in zip(d["district"], d["location_id"])}
        for e in ev.itertuples():
            for name in str(e.districts).split(";"):
                self.windows.setdefault(key[norm(name)], []).append(
                    (pd.Timestamp(e.start_date) - pd.Timedelta(days=2), pd.Timestamp(e.end_date)))
        self.cache = {}

    def _series(self, lat, lon):
        k = (round(lat, 4), round(lon, 4))
        if k in self.cache:
            return self.cache[k]
        rng = np.random.default_rng(abs(hash(k)) % (2**32))
        n = len(ALL_DAYS)
        doy = ALL_DAYS.dayofyear.to_numpy()
        monsoon = np.clip(np.sin(2 * np.pi * (doy - 120) / 365), 0, None)
        rain = rng.gamma(0.35, 7, n) * (0.3 + 2.5 * monsoon)
        loc = self.pts.get(k)
        for s, e in self.windows.get(loc, []):
            m = (ALL_DAYS >= s) & (ALL_DAYS <= e)
            rain[m] += rng.gamma(3, 22, m.sum())
        soil = pd.Series(rain).rolling(10, min_periods=1).mean().to_numpy() / 25
        t = 27 + 5 * np.sin(2 * np.pi * (doy - 100) / 365) + rng.normal(0, 1, n)
        data = {
            "IMERG_PRECTOT": rain * 0.95, "PRECTOTCORR": rain,
            "T2M": t, "T2M_MAX": t + 4, "T2M_MIN": t - 4, "T2MDEW": t - 3,
            "RH2M": 70 + 15 * monsoon + rng.normal(0, 3, n), "WS2M": 2 + rng.random(n),
            "PS": 100.5 - 0.4 * monsoon + rng.normal(0, 0.2, n),
            "GWETTOP": np.clip(soil, 0, 1), "GWETROOT": np.clip(soil * 0.9, 0, 1), "GWETPROF": np.clip(soil * 0.8, 0, 1),
            "ALLSKY_SFC_SW_DWN": 18 - 8 * monsoon + rng.normal(0, 1, n),
        }
        self.cache[k] = data
        return data

    def get(self, url, params=None, timeout=None):
        self.calls += 1
        plist = params["parameters"].split(",")
        comm = params["community"]
        bad = [p for p in plist if p == "GWETPROF" or (p == "IMERG_PRECTOT" and comm == "AG")]
        if bad:
            return FakeResponse(422, text=f"invalid parameters {bad}")
        data = self._series(float(params["latitude"]), float(params["longitude"]))
        s = pd.Timestamp(params["start"]); e = pd.Timestamp(params["end"])
        idx = [i for i, d in enumerate(ALL_DAYS) if s <= d <= e]
        today = pd.Timestamp(date.today())
        out = {}
        for p in plist:
            vals = {}
            for i in idx:
                d = ALL_DAYS[i]
                lag = 3 if p != "IMERG_PRECTOT" else 5
                v = float(data[p][i])
                vals[d.strftime("%Y%m%d")] = -999.0 if d > today - pd.Timedelta(days=lag) else round(v, 3)
            out[p] = vals
        return FakeResponse(200, {"properties": {"parameter": out}})
