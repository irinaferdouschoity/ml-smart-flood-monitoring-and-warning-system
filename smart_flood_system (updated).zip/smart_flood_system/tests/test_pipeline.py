"""End-to-end test of the whole pipeline with a fake NASA server. Run:  python -m unittest -v"""
import json
import shutil
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path
from unittest import mock

import pandas as pd

from floodml import config
from floodml.names import norm
from tests.fake_power import FakePower


class PipelineTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = Path(tempfile.mkdtemp())
        cls.saved = {k: getattr(config, k) for k in
                     ("POWER_DIR", "PLAN_JSON", "LABELS_CSV", "DATASET_CSV", "OUT", "MODEL_PATH", "METRICS_JSON",
                      "REPORT_MD", "OOF_CSV", "IMPORTANCE_CSV", "EVENT_CHECK_CSV", "PRED_CSV", "PRED_JSON")}
        config.POWER_DIR = cls.tmp / "power"
        config.PLAN_JSON = config.POWER_DIR / "_plan.json"
        config.LABELS_CSV = cls.tmp / "labels.csv"
        config.DATASET_CSV = cls.tmp / "dataset.csv"
        config.OUT = cls.tmp / "out"
        for name, fn in (("MODEL_PATH", "m.joblib"), ("METRICS_JSON", "metrics.json"), ("REPORT_MD", "report.md"),
                         ("OOF_CSV", "oof.csv"), ("IMPORTANCE_CSV", "imp.csv"), ("EVENT_CHECK_CSV", "ev.csv"),
                         ("PRED_CSV", "pred.csv"), ("PRED_JSON", "pred.json")):
            setattr(config, name, config.OUT / fn)
        cls.fake = FakePower()
        cls.patch = mock.patch("floodml.power_api.requests.get", cls.fake.get)
        cls.patch.start()

    @classmethod
    def tearDownClass(cls):
        cls.patch.stop()
        for k, v in cls.saved.items():
            setattr(config, k, v)
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def test_pipeline(self):
        from floodml.dataset import build_dataset
        from floodml.download import download_all, points
        from floodml.power_api import build_plan
        from floodml.predict import run_predict
        from floodml.train import run_training

        quiet = lambda *_: None
        # 1. parameter plan: IMERG must fall back from AG to another community, GWETPROF is skipped
        plan = build_plan(log=quiet)
        flat = sum(plan.values(), [])
        self.assertIn("IMERG_PRECTOT", flat)
        self.assertNotIn("IMERG_PRECTOT", plan.get("AG", []))
        self.assertNotIn("GWETPROF", flat)

        # 2. download all 70 points, then a second run must be cheap (resumable)
        start = date.fromisoformat(config.DEFAULT_START) - timedelta(days=config.WARMUP_DAYS)
        end = date.today() - timedelta(days=1)
        res = download_all(start, end, workers=4, log=quiet)
        self.assertEqual(res["errors"], {})
        self.assertEqual(len(list(config.POWER_DIR.glob("[0-9]*.csv"))), len(points()))
        calls = self.fake.calls
        download_all(start, end, workers=4, log=quiet)
        self.assertLess(self.fake.calls - calls, 4 * len(points()) * 3)

        # 3. dataset
        df = build_dataset()
        self.assertEqual(df["district"].nunique(), 64)
        self.assertGreater(df["flooded"].sum(), 300)
        self.assertIn("recession_buffer", set(df["label_status"]))
        self.assertTrue(df["date"].max() <= pd.Timestamp(config.LABELS_COMPLETE_UNTIL))
        # no label information may leak into features
        from floodml.train import feature_columns
        feats = feature_columns(df)
        for bad in ("flooded", "event_id", "label_status", "target", "district"):
            self.assertNotIn(bad, feats)

        # 4. features only look backwards: changing the future must not change today's features
        from floodml.features import build_features, load_power
        d = pd.read_csv(config.DISTRICTS_CSV); u = pd.read_csv(config.UPSTREAM_CSV)
        power = load_power(list(d.location_id) + list(u.location_id))
        a = build_features(power, d, u)
        cut = pd.Timestamp("2024-06-30")
        for k in power:
            p = power[k].copy()
            p.loc[p.index > cut, :] = p.loc[p.index > cut, :] + 500
            power[k] = p
        b = build_features(power, d, u)
        cols = [c for c in a.columns if c not in ("date", "location_id")]
        pa = a[a.date <= cut].sort_values(["location_id", "date"]).reset_index(drop=True)
        pb = b[b.date <= cut].sort_values(["location_id", "date"]).reset_index(drop=True)
        pd.testing.assert_frame_equal(pa[cols], pb[cols], check_exact=False, rtol=1e-9)

        # 5. training + validation
        m = run_training(log=quiet)
        self.assertGreaterEqual(len(m["per_year"]), 2)
        self.assertTrue(config.REPORT_MD.exists() and config.MODEL_PATH.exists())
        self.assertGreater(m["overall_out_of_fold"]["pr_auc"], m["overall_out_of_fold"]["baseline_rain3d_pr_auc"] * 0.5)

        # 6. prediction on the newest data (fake server lags a few days, like the real one)
        out = run_predict(refresh=True, days=75, workers=4, log=quiet)
        self.assertEqual(len(out), 64)
        self.assertEqual(out["location_id"].nunique(), 64)
        self.assertTrue(set(out["risk_level"]) <= {"LOW", "MODERATE", "HIGH", "VERY HIGH"})
        self.assertTrue((out["probability"].between(0, 1)).all())
        meta = json.loads(config.PRED_JSON.read_text())["meta"]
        self.assertLess(date.fromisoformat(meta["as_of"]), date.today() - timedelta(days=1))


if __name__ == "__main__":
    unittest.main()
