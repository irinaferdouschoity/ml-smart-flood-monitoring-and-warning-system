
"use strict";

const $ = (id) => document.getElementById(id);

let map = null;
let rainChart = null;
let tempChart = null;
let humChart = null;

// ---------- API helper ----------

async function api(url, options = {}) {
    const response = await fetch(url, {
        ...options,
        headers: {
            ...(options.headers || {}),
            ...(options.body ? { "Content-Type": "application/json" } : {})
        }
    });

    const text = await response.text();
    let data;

    try {
        data = text ? JSON.parse(text) : null;
    } catch {
        throw new Error(`Invalid server response (${response.status}).`);
    }

    if (!response.ok) {
        throw new Error(
            data?.detail || `Request failed: ${response.status}`
        );
    }

    return data;
}

function status(message) {
    const element = $("status");
    if (element) element.textContent = message;
}

function showError(message) {
    console.error(message);
    status(`Error: ${message}`);
}

function numeric(value) {
    if (value === null || value === undefined || value === "") {
        return null;
    }

    const result = Number(value);
    return Number.isFinite(result) ? result : null;
}

function displayNumber(value, suffix = "") {
    const result = numeric(value);
    return result === null ? "--" : `${result.toFixed(2)}${suffix}`;
}

function selectedCityId() {
    return Number($("locations")?.value || 0) || 0;
}

// Bangladesh districts use option values like "bd:105".
function selectedDistrictId() {
    const value = $("locations")?.value || "";
    return value.startsWith("bd:") ? Number(value.slice(3)) : 0;
}

// ---------- Graphs ----------

function drawChart(previous, canvasId, labels, values, title) {
    const canvas = $(canvasId);

    if (!canvas || typeof Chart === "undefined") {
        throw new Error(
            `Chart.js or canvas "${canvasId}" is unavailable.`
        );
    }

    if (previous) previous.destroy();

    return new Chart(canvas, {
        type: "line",
        data: {
            labels: labels,
            datasets: [{
                label: title,
                data: values,
                borderWidth: 2,
                pointRadius: 2,
                tension: 0.2,
                spanGaps: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            interaction: {
                intersect: false,
                mode: "index"
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// ---------- Weather ----------

async function weather(id) {
    const records = await api(`/weather/${id}?limit=90`);

    if (!Array.isArray(records)) {
        throw new Error("Weather data is not in the expected format.");
    }

    // The API returns the observations oldest to newest.
    const labels = records.map(row =>
        String(row.observation_date ?? row.date ?? "")
    );

    rainChart = drawChart(
        rainChart,
        "rain",
        labels,
        records.map(row => numeric(row.precipitation)),
        "Rainfall (mm)"
    );

    tempChart = drawChart(
        tempChart,
        "temp",
        labels,
        records.map(row =>
            numeric(row.temperature_avg ?? row.temperature)
        ),
        "Temperature"
    );

    humChart = drawChart(
        humChart,
        "humidity",
        labels,
        records.map(row =>
            numeric(row.humidity_avg ?? row.humidity)
        ),
        "Humidity (%)"
    );

    const latest = records.length
        ? records[records.length - 1]
        : null;

    if ($("r24")) {
        $("r24").textContent = latest
            ? displayNumber(latest.precipitation, " mm")
            : "--";
    }

    const last7 = records.slice(-7);
    const rainValues = last7.map(row => numeric(row.precipitation));

    if ($("r7")) {
        $("r7").textContent = rainValues.some(value => value !== null)
            ? `${rainValues.reduce(
                (sum, value) => sum + (value ?? 0), 0
            ).toFixed(2)} mm`
            : "--";
    }
}

// ---------- Flood history ----------

async function history(id) {
    renderHistory(await api(`/flood-history/${id}`));
}

function renderHistory(records) {
    const container = $("history");

    if (!container) return;

    container.replaceChildren();

    if (!Array.isArray(records) || records.length === 0) {
        container.textContent = "No flood history available.";
        return;
    }

    const table = document.createElement("table");
    const header = document.createElement("tr");

    ["Date", "Severity", "Description"].forEach(text => {
        const cell = document.createElement("th");
        cell.textContent = text;
        header.appendChild(cell);
    });

    table.appendChild(header);

    records.forEach(record => {
        const row = document.createElement("tr");

        [
            record.event_date ?? "--",
            record.severity ?? "--",
            record.description ?? record.details ?? "--"
        ].forEach(value => {
            const cell = document.createElement("td");
            cell.textContent = String(value);
            row.appendChild(cell);
        });

        table.appendChild(row);
    });

    container.appendChild(table);
}

// ---------- Historical rainfall indicator ----------

async function loadRainfallIndicator(id) {
    const result = await api(`/rainfall-indicator/${id}`);

    if ($("rainfallIndicator")) {
        $("rainfallIndicator").textContent =
            result.rainfall_indicator ?? "--";
    }

    if ($("rainfallDetails")) {
        $("rainfallDetails").textContent =
            result.note
                ? `${result.note} Date: ${result.observation_date ?? "--"}`
                : `Date: ${result.observation_date ?? "--"}`;
    }
}

// ---------- Selected city ----------

async function selected() {
    const districtId = selectedDistrictId();

    if (districtId) {
        await districtSelected(districtId);
        return;
    }

    const id = selectedCityId();

    if (!id) {
        status("Please select a location.");
        return;
    }

    status("Loading city data...");

    const results = await Promise.allSettled([
        weather(id),
        history(id),
        loadRainfallIndicator(id)
    ]);

    const failures = results
        .filter(result => result.status === "rejected")
        .map(result => result.reason?.message || "Unknown error");

    if (failures.length) {
        showError(failures.join(" | "));
        return;
    }

    if ($("risk")) $("risk").textContent = "--";
    if ($("prob")) $("prob").textContent = "--";

    status("City data loaded.");
}

// ---------- Load cities and map ----------

async function load() {
    status("Loading locations...");

    const locations = await api("/locations");

    if (!Array.isArray(locations)) {
        throw new Error("The locations API did not return a list.");
    }

    const select = $("locations");

    if (!select) {
        throw new Error('Missing HTML element: id="locations".');
    }

    select.replaceChildren();

    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = "Select a location";
    select.appendChild(placeholder);

    locations.forEach(location => {
        const option = document.createElement("option");
        option.value = String(location.location_id);
        option.textContent =
            `${location.location_name}, ${location.country}`;
        select.appendChild(option);
    });

    if (map) {
        map.eachLayer(layer => {
            if (layer instanceof L.CircleMarker) {
                map.removeLayer(layer);
            }
        });

        locations.forEach(location => {
            const latitude = numeric(location.latitude);
            const longitude = numeric(location.longitude);

            if (latitude === null || longitude === null) return;

            L.circleMarker([latitude, longitude], { radius: 6 })
                .addTo(map)
                .bindPopup(
                    `${location.location_name}, ${location.country}`
                );
        });
    }

    await addDistrictOptions(select);
    loadAllDistricts();

    if (!locations.length) {
        status("No locations were returned by the API.");
        return;
    }

    select.value = String(locations[0].location_id);

    if (map) {
        const first = locations[0];
        const latitude = numeric(first.latitude);
        const longitude = numeric(first.longitude);

        if (latitude !== null && longitude !== null) {
            map.setView([latitude, longitude], 6);
        }
    }

    await selected();
}

// ---------- City-based Haor model prediction ----------

async function predict() {
    const districtId = selectedDistrictId();

    if (districtId) {
        await districtPredict(districtId);
        return;
    }

    const id = selectedCityId();

    if (!id) {
        status("Please select a location.");
        return;
    }

    const button = $("predict");
    if (button) button.disabled = true;

    status("Running experimental Haor model with latest city weather...");

    try {
        const result = await api(
            `/city-haor-predict?location_id=${encodeURIComponent(id)}`,
            { method: "POST" }
        );

        const probability = Number(result.flood_probability);

        if (!Number.isFinite(probability)) {
            throw new Error("The API returned an invalid probability.");
        }

        if ($("risk")) $("risk").textContent = result.risk_level ?? "--";

        if ($("prob")) {
            $("prob").textContent =
                `${(probability * 100).toFixed(1)}%`;
        }

        status(
            `Experimental estimate for ${result.city}, based on weather ` +
            `dated ${result.weather_observation_date}.`
        );

        const resultBox = $("haor-result");

        if (resultBox) {
            resultBox.replaceChildren();

            const details = [
                ["Experimental Haor model result", true],
                [`City: ${result.city}`, false],
                [`Latest weather date: ${result.weather_observation_date}`, false],
                [`Model output: ${(probability * 100).toFixed(1)}%`, false],
                [`Model category: ${result.risk_level}`, false],
                [`Warning: ${result.warning ?? "Research estimate only."}`, false],
                [
                    "Unavailable live satellite/terrain features: " +
                    (result.missing_live_features || []).join(", "),
                    false
                ]
            ];

            details.forEach(([text, isHeading]) => {
                const element = document.createElement(
                    isHeading ? "h3" : "p"
                );
                element.textContent = text;
                resultBox.appendChild(element);
            });
        }
    } catch (error) {
        showError(`Prediction failed: ${error.message}`);
    } finally {
        if (button) button.disabled = false;
    }
}

// ---------- Refresh NASA data ----------

async function update() {
    const button = $("refresh");
    if (button) button.disabled = true;

    try {
        const districtId = selectedDistrictId();

        if (districtId) {
            status("Downloading the newest NASA data for all 64 districts (about a minute)...");
            await api("/bd/refresh", { method: "POST" });
            await loadAllDistricts();
            await districtSelected(districtId);
            status("District data and predictions updated.");
            return;
        }

        status("Downloading NASA weather data (the first time can take a minute)...");

        const result = await api("/sync-nasa", {
            method: "POST"
        });

        const failures = Array.isArray(result.results)
            ? result.results.filter(item => item.status === "error")
            : [];

        await load();

        if (failures.length) {
            status(
                `Update finished with ${failures.length} location error(s).`
            );
        } else {
            status("NASA data update completed.");
        }
    } catch (error) {
        showError(`Update failed: ${error.message}`);
    } finally {
        if (button) button.disabled = false;
    }
}

// ---------- Manual 14-feature Haor research model ----------

async function predictHaor(event) {
    event.preventDefault();

    const form = $("haor-form");
    const resultBox = $("haor-result");

    if (!form) return;

    const fields = [
        "VV", "VH", "vv_vh_ratio", "rainfall",
        "soil_moisture", "temp", "wind", "slope",
        "twi", "rain_24h", "ndwi", "upstream_vv",
        "rain_96h", "temp_anomaly"
    ];

    const features = {};

    for (const name of fields) {
        const input = form.elements.namedItem(name);

        if (!input || input.value.trim() === "") {
            if (resultBox) {
                resultBox.textContent = `Please enter ${name}.`;
            }
            return;
        }

        const value = Number(input.value);

        if (!Number.isFinite(value)) {
            if (resultBox) {
                resultBox.textContent = `${name} must be numeric.`;
            }
            return;
        }

        features[name] = value;
    }

    const button = $("haor-submit");
    if (button) button.disabled = true;

    if (resultBox) resultBox.textContent = "Running research model...";

    try {
        const result = await api("/haor-predict", {
            method: "POST",
            body: JSON.stringify({ features })
        });

        if (resultBox) {
            resultBox.replaceChildren();

            const heading = document.createElement("h3");
            heading.textContent = "Haor research model result";

            const probability = document.createElement("p");
            probability.textContent =
                `Model output: ${
                    (Number(result.flood_probability) * 100).toFixed(1)
                }%`;

            const level = document.createElement("p");
            level.textContent = `Model category: ${result.risk_level}`;

            const warning = document.createElement("p");
            warning.textContent = result.warning ?? "Experimental result.";

            resultBox.append(heading, probability, level, warning);
        }
    } catch (error) {
        if (resultBox) {
            resultBox.textContent = `Prediction failed: ${error.message}`;
        }
        showError(`Haor prediction failed: ${error.message}`);
    } finally {
        if (button) button.disabled = false;
    }
}

// ---------- Bangladesh: all 64 districts ----------

const RISK_COLORS = {
    "LOW": "#3b9c5a",
    "MODERATE": "#f2b134",
    "HIGH": "#ef6c00",
    "VERY HIGH": "#c62828"
};

let bdMarkers = {};

async function addDistrictOptions(select) {
    let districts;

    try {
        districts = await api("/bd/districts");
    } catch (error) {
        return;   // the district module is optional
    }

    if (!Array.isArray(districts) || !districts.length) return;

    const group = document.createElement("optgroup");
    group.label = "Bangladesh districts (64)";

    districts
        .slice()
        .sort((a, b) => a.district.localeCompare(b.district))
        .forEach(item => {
            const option = document.createElement("option");
            option.value = `bd:${item.location_id}`;
            option.textContent = `${item.district} (${item.division})`;
            group.appendChild(option);
        });

    select.appendChild(group);

    bdMarkers = {};

    if (map) {
        districts.forEach(item => {
            bdMarkers[item.location_id] = L.circleMarker(
                [item.latitude, item.longitude],
                { radius: 5, color: "#555", weight: 1, fillColor: "#999", fillOpacity: 0.6 }
            )
                .addTo(map)
                .bindPopup(`${item.district}, ${item.division} Division`);
        });
    }
}

function openDistrict(locationId) {
    const select = $("locations");
    if (!select) return;

    select.value = `bd:${locationId}`;
    selected().catch(error => showError(error.message));
}

async function loadAllDistricts() {
    const box = $("bd-all");
    if (!box) return;

    try {
        const payload = await api("/bd/predictions");
        const rows = payload.districts || [];

        box.replaceChildren();

        const info = document.createElement("p");
        info.textContent =
            `Conditions as of ${payload.meta.as_of}: chance of a flood within ` +
            `${payload.meta.horizon_days} days. Click a row to open the district.`;
        box.appendChild(info);

        const wrap = document.createElement("div");
        wrap.style.maxHeight = "420px";
        wrap.style.overflow = "auto";

        const table = document.createElement("table");
        const head = document.createElement("tr");

        ["#", "District", "Division", "Risk", "Chance", "Rain 3 days"].forEach(text => {
            const cell = document.createElement("th");
            cell.textContent = text;
            head.appendChild(cell);
        });

        table.appendChild(head);

        rows.forEach(item => {
            const row = document.createElement("tr");
            row.style.cursor = "pointer";
            row.addEventListener("click", () => openDistrict(item.location_id));

            [
                item.rank,
                item.district,
                item.division,
                item.risk_level,
                `${(Number(item.probability) * 100).toFixed(1)}%`,
                `${item.rain_3d_mm} mm`
            ].forEach((value, index) => {
                const cell = document.createElement("td");
                cell.textContent = String(value);

                if (index === 3) {
                    cell.style.color = RISK_COLORS[item.risk_level] || "inherit";
                    cell.style.fontWeight = "700";
                }

                row.appendChild(cell);
            });

            table.appendChild(row);

            const marker = bdMarkers[item.location_id];

            if (marker) {
                const color = RISK_COLORS[item.risk_level] || "#999";
                marker.setStyle({ fillColor: color, color: color, fillOpacity: 0.85 });
                marker.setRadius(item.risk_level === "LOW" ? 5 : 9);
            }
        });

        wrap.appendChild(table);
        box.appendChild(wrap);
    } catch (error) {
        box.textContent =
            `No district predictions yet. ${error.message} ` +
            "Run run_ml.bat (option 1) to download NASA data and train the model.";
    }
}

async function districtSelected(id) {
    status("Loading district data...");

    const data = await api(`/bd/district/${id}`);
    const weatherRows = data.weather || [];
    const labels = weatherRows.map(row => row.date);

    rainChart = drawChart(
        rainChart, "rain", labels,
        weatherRows.map(row => numeric(row.precipitation)),
        "Rainfall (mm) - NASA IMERG / POWER"
    );

    tempChart = drawChart(
        tempChart, "temp", labels,
        weatherRows.map(row => numeric(row.temperature_avg)),
        "Temperature (C)"
    );

    humChart = drawChart(
        humChart, "humidity", labels,
        weatherRows.map(row => numeric(row.humidity)),
        "Humidity (%)"
    );

    const latest = weatherRows.length ? weatherRows[weatherRows.length - 1] : null;
    const last7 = weatherRows.slice(-7).map(row => numeric(row.precipitation));

    if ($("r24")) {
        $("r24").textContent = latest ? displayNumber(latest.precipitation, " mm") : "--";
    }

    if ($("r7")) {
        $("r7").textContent = last7.some(value => value !== null)
            ? `${last7.reduce((sum, value) => sum + (value ?? 0), 0).toFixed(2)} mm`
            : "--";
    }

    renderHistory(data.history || []);

    const prediction = data.prediction;

    if ($("risk")) $("risk").textContent = prediction ? prediction.risk_level : "--";

    if ($("prob")) {
        $("prob").textContent = prediction
            ? `${(Number(prediction.probability) * 100).toFixed(1)}%`
            : "--";
    }

    if ($("rainfallIndicator")) {
        $("rainfallIndicator").textContent = prediction ? `${prediction.rain_3d_mm} mm / 3 days` : "--";
    }

    if ($("rainfallDetails")) {
        $("rainfallDetails").textContent = prediction
            ? `District model input, as of ${prediction.as_of}`
            : "No prediction yet";
    }

    if (map) map.setView([data.latitude, data.longitude], 8);

    status(
        (data.notes || []).length
            ? data.notes.join(" ")
            : `${data.district}: data loaded. Press "Run prediction" for the model result.`
    );
}

async function districtPredict(id) {
    const button = $("predict");
    if (button) button.disabled = true;

    status("Loading the district model result...");

    try {
        const data = await api(`/bd/district/${id}`);
        const p = data.prediction;

        if (!p) {
            throw new Error((data.notes || []).join(" ") || "No prediction available yet.");
        }

        const probability = Number(p.probability);

        if ($("risk")) $("risk").textContent = p.risk_level;
        if ($("prob")) $("prob").textContent = `${(probability * 100).toFixed(1)}%`;

        status(
            `${data.district}: ${p.risk_level} - chance of a flood within ` +
            `${p.horizon_days} days, based on NASA data as of ${p.as_of}.`
        );

        const box = $("haor-result");

        if (box) {
            box.replaceChildren();

            [
                [`Bangladesh district model: ${data.district} (${data.division} Division)`, true],
                [`Conditions as of: ${p.as_of} (NASA POWER / IMERG)`, false],
                [`Chance of a flood within ${p.horizon_days} days: ${(probability * 100).toFixed(1)}%`, false],
                [`Risk level: ${p.risk_level} (rank ${p.rank} of 64)`, false],
                [`Rain: ${p.rain_1d_mm} mm today, ${p.rain_3d_mm} mm in 3 days, ${p.rain_7d_mm} mm in 7 days`, false],
                [`Root-zone soil wetness: ${p.soil_wetness_root}`, false],
                [`Note: ${data.prediction_meta?.caveat ?? "Research estimate only."}`, false]
            ].forEach(([text, isHeading]) => {
                const element = document.createElement(isHeading ? "h3" : "p");
                element.textContent = text;
                box.appendChild(element);
            });
        }
    } catch (error) {
        showError(`Prediction failed: ${error.message}`);
    } finally {
        if (button) button.disabled = false;
    }
}

// ---------- Start dashboard ----------

document.addEventListener("DOMContentLoaded", async () => {
    try {
        if (typeof L === "undefined") {
            throw new Error(
                "Leaflet did not load. Check your internet connection."
            );
        }

        if (typeof Chart === "undefined") {
            throw new Error(
                "Chart.js did not load. Check your internet connection."
            );
        }

        map = L.map("map").setView([20, 0], 2);

        L.tileLayer(
            "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
            { attribution: "© OpenStreetMap contributors" }
        ).addTo(map);

        $("locations")?.addEventListener("change", async () => {
            try {
                await selected();
            } catch (error) {
                showError(error.message);
            }
        });

        $("predict")?.addEventListener("click", predict);
        $("refresh")?.addEventListener("click", update);
        $("haor-form")?.addEventListener("submit", predictHaor);

        await load();
    } catch (error) {
        showError(`Dashboard loading failed: ${error.message}`);
    }
});
