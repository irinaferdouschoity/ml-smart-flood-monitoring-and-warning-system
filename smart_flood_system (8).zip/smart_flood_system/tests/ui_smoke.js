// Smoke test of frontend/app.js with a fake browser. Run:  node tests/ui_smoke.js
const fs = require("fs");
const vm = require("vm");
const assert = require("assert");

function fakeEl() {
  const el = {
    value: "", textContent: "", style: { setProperty() {} }, children: [], handlers: {}, disabled: false, label: "",
    appendChild(c) { this.children.push(c); return c; },
    replaceChildren(...c) { this.children = c; this.textContent = ""; },
    addEventListener(ev, fn) { this.handlers[ev] = fn; },
    classList: { add() {}, remove() {} }, dataset: {},
    get options() { return this.children.flatMap(c => (c.label !== undefined && c.children.length ? c.children : [c])); },
    get selectedIndex() { return this.options.findIndex(o => o.value === this.value); },
  };
  return el;
}
const els = {};
const docHandlers = {};
const document = {
  getElementById: id => (els[id] ||= fakeEl()),
  createElement: () => fakeEl(),
  createTextNode: text => ({ textContent: String(text) }),
  addEventListener: (ev, fn) => { docHandlers[ev] = fn; },
};
const markers = [];
const L = {
  map: () => ({ setView() { return this; }, eachLayer() {}, removeLayer() {} }),
  tileLayer: () => ({ addTo() {} }),
  circleMarker: () => { const m = { styled: null, addTo() { return this; }, bindPopup() { return this; },
    setStyle(s) { this.styled = s; }, setRadius() {} }; markers.push(m); return m; },
  CircleMarker: class {},
};
const charts = [];
class Chart { constructor(c, cfg) { this.cfg = cfg; charts.push(this); } destroy() {} }

const pred = { rank: 3, location_id: 101, district: "Gazipur", division: "Dhaka", as_of: "2026-11-10", horizon_days: 3,
  probability: 0.1234, risk_level: "HIGH", rain_1d_mm: 5.1, rain_3d_mm: 40.2, rain_7d_mm: 80.5, soil_wetness_root: 0.71 };
const meta = { as_of: "2026-11-10", horizon_days: 3, caveat: "Research model." };
const weather = Array.from({ length: 10 }, (_, i) => ({ date: `2026-11-0${i % 9 + 1}`, precipitation: i, temperature_avg: 25, humidity: 80 }));
let withPred = true;
// 40 days: 5 Oct .. 13 Nov 2026; rain = 0,1,2 ... 39 mm  (so November = days 27..39: average 33, total 429)
const cityWeather = Array.from({ length: 40 }, (_, i) => ({
  observation_date: new Date(Date.UTC(2026, 9, 5 + i)).toISOString().slice(0, 10),
  precipitation: i, temperature_avg: 20 + i / 10, humidity: 70 }));

async function fetch(url, opts = {}) {
  const ok = (data, status = 200) => ({ ok: status < 400, status, text: async () => JSON.stringify(data) });
  if (url === "/locations") return ok([{ location_id: 1, location_name: "Dhaka", country: "Bangladesh", latitude: 23.8, longitude: 90.4 }]);
  if (url.startsWith("/weather/")) return ok(cityWeather);
  if (url.startsWith("/flood-history/")) return ok([]);
  if (url.startsWith("/rainfall-indicator/")) return ok({ rainfall_indicator: "High rainfall", observation_date: "2026-11-13",
    rainfall_3day_total: 120.5, threshold_95: 78.58, threshold_99: 147.1 });
  if (url === "/bd/districts") return ok([
    { location_id: 1, district: "Dhaka", division: "Dhaka", latitude: 23.8, longitude: 90.4 },
    { location_id: 101, district: "Gazipur", division: "Dhaka", latitude: 24, longitude: 90.4 }]);
  if (url === "/bd/predictions") return withPred ? ok({ meta, districts: [pred] }) : ok({ detail: "No predictions yet." }, 404);
  if (url === "/bd/district/1") return ok({ location_id: 1, district: "Dhaka", division: "Dhaka", latitude: 23.8, longitude: 90.4,
    prediction: { ...pred, location_id: 1, district: "Dhaka", rank: 1 }, prediction_meta: meta, weather, history: [], notes: [] });
  if (url === "/bd/district/101") return ok({ location_id: 101, district: "Gazipur", division: "Dhaka", latitude: 24, longitude: 90.4,
    prediction: withPred ? pred : null, prediction_meta: meta, weather,
    history: [{ event_date: "2024-06-15 to 2024-06-30", severity: "medium confidence", description: "x" }],
    notes: withPred ? [] : ["No prediction yet."] });
  if (url === "/bd/refresh") return ok({});
  throw new Error("unexpected url " + url);
}

const ctx = { document, L, Chart, fetch, console, Promise, Number, String, Array, JSON, Object, Math, Error, Date, Set, setTimeout };
ctx.window = ctx;
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(__dirname + "/../frontend/app.js", "utf8"), ctx);

(async () => {
  await docHandlers.DOMContentLoaded();
  await new Promise(r => setTimeout(r, 20));

  const select = els.locations;
  const group = select.children.find(c => c.label && c.label.includes("Bangladesh districts"));
  assert(group, "district option group missing");
  assert.strictEqual(group.children.length, 2);
  assert(els["bd-all"].children.length >= 2, "all-districts table missing");
  assert.strictEqual(markers[markers.length - 1].styled.fillColor, "#e36b2c", "marker not coloured by risk");

  // a city from the database: latest day, month average and a day-to-day table appear next to the charts
  select.value = "5";
  await select.handlers.change();
  assert.strictEqual(els.r24Date.textContent, "(2026-11-13)");
  assert(els["rain-note"].textContent.includes("November 2026 average: 33.0 mm per day"), els["rain-note"].textContent);
  const summaryTable = els["weather-summary"].children[0];
  const rainRow = summaryTable.children[1].children.map(c => c.textContent);
  assert.deepStrictEqual(rainRow, ["Rainfall (mm per day)", "39.0", "33.0", "total 429.0 mm"]);
  const dailyTable = els["daily-table"].children[0];
  assert.strictEqual(dailyTable.children.length, 31);                       // header + 30 days
  assert.strictEqual(dailyTable.children[1].children[0].textContent, "2026-11-13");
  assert.strictEqual(dailyTable.children[1].className, "latest");
  // the indicator shows the SAME newest date as the charts (not an older saved-file date)
  assert(els.rainfallDetails.textContent.includes("2026-11-13"), els.rainfallDetails.textContent);

  // choose a district -> data loads
  select.value = "bd:101";
  await select.handlers.change();
  assert.strictEqual(els.risk.textContent, "HIGH");
  assert.strictEqual(els.prob.textContent, "12.3%");
  assert(charts.length >= 3, "charts not drawn");

  // run prediction -> detail box filled
  els.risk.textContent = "--";
  await els.predict.handlers.click();
  assert.strictEqual(els.risk.textContent, "HIGH");
  assert(els["haor-result"].children.length >= 6, "detail panel not filled");
  assert(els.status.textContent.includes("Gazipur"));

  // Dhaka from the database (a Bangladesh city) is predicted with the district model, not the old Haor model
  select.value = "1";
  els["haor-result"].children = [];
  await els.predict.handlers.click();
  assert(els["haor-result"].children[0].textContent.includes("Dhaka"), "Dhaka did not use the district model");

  // refresh button with a district selected uses /bd/refresh
  select.value = "bd:101";
  await els.refresh.handlers.click();
  assert(els.status.textContent.includes("updated"), els.status.textContent);

  // no model yet -> clear message, no crash
  withPred = false;
  await els.predict.handlers.click();
  assert(els.status.textContent.startsWith("Error:") && els.status.textContent.includes("No prediction"), els.status.textContent);
  // ---- light / dark switch (theme.js) ----
  const store = {};
  const themeCtx = { document: { documentElement: { dataset: {} }, getElementById: id => (els[id] ||= fakeEl()),
      addEventListener: (ev, fn) => { themeCtx.docHandlers[ev] = fn; } }, docHandlers: {},
    localStorage: { getItem: k => store[k] ?? null, setItem: (k, v) => { store[k] = v; } },
    matchMedia: () => ({ matches: false }), CustomEvent: class { constructor(n, o) { this.type = n; this.detail = o?.detail; } }, events: [] };
  themeCtx.window = themeCtx; themeCtx.dispatchEvent = e => themeCtx.events.push(e.type);
  vm.createContext(themeCtx);
  vm.runInContext(fs.readFileSync(__dirname + "/../frontend/theme.js", "utf8"), themeCtx);
  els.themeToggle = fakeEl();
  themeCtx.docHandlers.DOMContentLoaded();
  assert.strictEqual(els.themeToggle.textContent, "Switch to dark mode");
  els.themeToggle.handlers.click();
  assert.strictEqual(themeCtx.document.documentElement.dataset.theme, "dark");
  assert.strictEqual(store.theme, "dark");
  assert.strictEqual(els.themeToggle.textContent, "Switch to light mode");
  els.themeToggle.handlers.click();
  assert.strictEqual(themeCtx.document.documentElement.dataset.theme, "light");
  assert.strictEqual(els.themeToggle.textContent, "Switch to dark mode");
  assert.deepStrictEqual(themeCtx.events, ["themechange", "themechange"]);
  console.log("UI smoke test OK");
})().catch(e => { console.error("FAILED:", e.message); process.exit(1); });
