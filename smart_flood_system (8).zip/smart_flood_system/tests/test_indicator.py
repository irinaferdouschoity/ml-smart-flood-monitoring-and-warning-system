"""Tests for the rainfall indicator. Run:  python -m unittest -v tests.test_indicator"""
import unittest
from datetime import date

import pandas as pd

from backend.services.indicator import BELOW, HIGH, VERY_HIGH, choose_source, classify, three_day_total
from floodml import config


class IndicatorTest(unittest.TestCase):
    def test_three_day_total_uses_newest_day_not_the_csv_date(self):
        rows = [(date(2026, 11, 9), 10.0), (date(2026, 11, 8), 5.0), (date(2026, 11, 7), 1.5), (date(2026, 11, 6), 99.0)]
        self.assertEqual(three_day_total(rows), (date(2026, 11, 9), 16.5))

    def test_missing_values_and_empty(self):
        self.assertEqual(three_day_total([]), (None, None))
        self.assertEqual(three_day_total([(date(2026, 11, 9), None)]), (None, None))
        self.assertEqual(three_day_total([(date(2026, 11, 9), 4.0), (date(2026, 11, 8), None)]), (date(2026, 11, 9), 4.0))

    def test_classify_matches_the_saved_history_file(self):
        d = pd.read_csv(config.DATA / "city_specific_risk.csv", encoding="utf-8-sig")
        sample = d.dropna(subset=["rainfall_3day_total"]).sample(2000, random_state=1)
        for r in sample.itertuples():
            self.assertEqual(classify(r.rainfall_3day_total, r.threshold_95, r.threshold_99), r.rainfall_indicator)
        self.assertEqual({BELOW, HIGH, VERY_HIGH}, set(d["rainfall_indicator"]))

    def test_source_choice(self):
        self.assertEqual(choose_source("2026-10-05", date(2026, 11, 9)), "live")      # the October bug
        self.assertEqual(choose_source("2026-10-05", date(2026, 10, 5)), "live")
        self.assertEqual(choose_source("2026-10-05", date(2026, 9, 1)), "csv")
        self.assertEqual(choose_source("2026-10-05", None), "csv")
        self.assertEqual(choose_source(None, date(2026, 11, 9)), "live")


if __name__ == "__main__":
    unittest.main()
