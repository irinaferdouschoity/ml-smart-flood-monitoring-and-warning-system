"""Tests for the MySQL export (run against SQLite so no server is needed).
Run:  python -m unittest -v tests.test_mysql_export"""
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

import pandas as pd

from floodml import config
from floodml.labels import build_labels
from floodml.mysql_export import (Db, MySQLUnavailable, connect_mysql, export_all, parse_url)


class ExportTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.saved = (config.POWER_DIR, config.PRED_JSON)
        config.POWER_DIR = self.tmp / "power"
        config.POWER_DIR.mkdir()
        config.PRED_JSON = self.tmp / "pred.json"
        idx = pd.date_range("2026-10-01", periods=6, name="date")
        df = pd.DataFrame({"IMERG_PRECTOT": [5.0, None, 7.0, 1.0, None, None],
                           "PRECTOTCORR": [4.0, 3.0, 6.0, 2.0, None, None],
                           "T2M": 27.0, "GWETROOT": 0.6}, index=idx)
        df.iloc[-1, :] = float("nan")                         # a day with no data at all
        df.to_csv(config.POWER_DIR / "101.csv")
        df.to_csv(config.POWER_DIR / "9001.csv")              # an upstream station
        self.db = Db(sqlite3.connect(":memory:"), "sqlite")
        self.quiet = lambda *_: None

    def tearDown(self):
        config.POWER_DIR, config.PRED_JSON = self.saved
        self.db.close()

    def _write_predictions(self, prob):
        rows = [{"location_id": 101, "district": "Gazipur", "as_of": "2026-10-05", "horizon_days": 3, "score": 0.5,
                 "probability": prob, "risk_level": "HIGH", "rain_1d_mm": 1.0, "rain_3d_mm": 2.0, "rain_7d_mm": 3.0,
                 "soil_wetness_root": 0.7}]
        config.PRED_JSON.write_text(json.dumps({"meta": {"model_trained_at": "2026-11-01T00:00:00Z"}, "districts": rows}))

    def test_full_export_and_idempotence(self):
        self._write_predictions(0.2)
        res = export_all(self.db, log=self.quiet)
        self.assertEqual(res["locations"], 70)                       # 64 districts + 6 upstream
        self.assertEqual(self.db.scalar("SELECT COUNT(*) FROM bd_daily_data"), 10)   # 5 valid days x 2 files
        self.assertEqual(self.db.scalar("SELECT COUNT(*) FROM bd_flood_events"), 43)
        self.assertEqual(self.db.scalar("SELECT COUNT(*) FROM bd_flood_days"), len(build_labels(write=False)))
        self.assertEqual(self.db.scalar("SELECT COUNT(*) FROM bd_predictions"), 1)

        # rainfall = IMERG, falling back to corrected precipitation; NaN becomes NULL
        rows = dict(self.db.execute("SELECT observation_date, rain_mm FROM bd_daily_data WHERE location_id=101").fetchall())
        self.assertEqual(rows["2026-10-01"], 5.0)
        self.assertEqual(rows["2026-10-02"], 3.0)
        self.assertIsNone(self.db.scalar("SELECT imerg_precip FROM bd_daily_data WHERE location_id=101 AND observation_date='2026-10-02'"))
        self.assertNotIn("2026-10-06", rows)

        # running again never duplicates; changed values are updated
        changed = pd.read_csv(config.POWER_DIR / "101.csv")
        changed.loc[changed["T2M"].notna(), "T2M"] = 30.0          # only the days that have data
        changed.to_csv(config.POWER_DIR / "101.csv", index=False)
        self._write_predictions(0.4)
        export_all(self.db, log=self.quiet)
        self.assertEqual(self.db.scalar("SELECT COUNT(*) FROM bd_daily_data"), 10)
        self.assertEqual(self.db.scalar("SELECT t2m FROM bd_daily_data WHERE location_id=101 AND observation_date='2026-10-01'"), 30.0)
        self.assertEqual(self.db.scalar("SELECT COUNT(*) FROM bd_predictions"), 1)
        self.assertAlmostEqual(self.db.scalar("SELECT probability FROM bd_predictions"), 0.4)

        # the convenience view joins names
        v = self.db.execute("SELECT district, risk_level FROM bd_latest_risk").fetchall()
        self.assertEqual(v, [("Gazipur", "HIGH")])

    def test_since_filter(self):
        export_all(self.db, only="daily", since="2026-10-04", log=self.quiet)
        self.assertEqual(self.db.scalar("SELECT COUNT(*) FROM bd_daily_data"), 4)      # 2 days x 2 files

    def test_mysql_sql_and_url(self):
        mysql = Db(conn=None, dialect="mysql")
        sql = mysql.upsert_sql("t", ["a", "b", "c"], ["a"])
        self.assertIn("%s", sql)
        self.assertTrue(sql.endswith("ON DUPLICATE KEY UPDATE b=VALUES(b),c=VALUES(c)"))
        cfg = parse_url("mysql+pymysql://root:p%40ss@localhost/smart_flood_system")
        self.assertEqual((cfg["user"], cfg["password"], cfg["port"], cfg["database"]),
                         ("root", "p@ss", 3306, "smart_flood_system"))
        self.assertEqual(parse_url("mysql+pymysql://root:@localhost:3307/x")["password"], "")

    def test_unreachable_mysql_is_a_friendly_error(self):
        import os
        old = os.environ.get("DATABASE_URL")
        os.environ["DATABASE_URL"] = "mysql+pymysql://root:@127.0.0.1:1/nothing"
        try:
            with self.assertRaises(MySQLUnavailable):
                connect_mysql()
        finally:
            if old is None:
                os.environ.pop("DATABASE_URL")
            else:
                os.environ["DATABASE_URL"] = old


if __name__ == "__main__":
    unittest.main()
